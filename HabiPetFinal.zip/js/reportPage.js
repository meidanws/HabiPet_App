﻿
//$(document).ready(function () {

//    var data = {
//        serviceOnAirId: 8 /// need to take serviceOnAirId ///!!!!!!
//    };
//    ajax.sendWithData("PathAPI.asmx/GetCurrentReport", data, SuccessGetCurrentReport, ErrorGetCurrentReport);


//});

//function SuccessGetCurrentReport() {

//    alert("SUCCSES");
//};
//function ErrorGetCurrentReport() {
//    alert("failll");
//};


//function getCurrentReport() {

//}